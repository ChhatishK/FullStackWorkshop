package in.sp.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.sp.dbcon.DbConnection;

public class Register extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter out = resp.getWriter();
		resp.setContentType("text/html");
		
		String myName = req.getParameter("name");
		String myEmail = req.getParameter("email");
		String myPass = req.getParameter("password");
		String myCity = req.getParameter("city");
		
		try {
			Connection con = DbConnection.getConnection();
			
			String insert_sql_query = "INSERT INTO register VALUES(?, ?, ?, ?)";
			PreparedStatement ps = con.prepareStatement("");
			ps.setString(1, myName);
			ps.setString(2, myEmail);
			ps.setString(3, myPass);
			ps.setString(4, myCity);
		} catch(Exception e) {
			
		}
	}
}
