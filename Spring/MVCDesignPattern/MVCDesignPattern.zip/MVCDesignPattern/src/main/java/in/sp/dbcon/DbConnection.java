package in.sp.dbcon;

import java.sql.Connection;

public class DbConnection {
	public static Connection getConnection() {
		Connection con = null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			con.DriverManager.getConnection("jdbc:mysql://localhost:3306/mvc_db", "root", "Hasan@773311");
			
		} catch(Exception e) {
			e.printStackTrace(e);
		}
	}

}
