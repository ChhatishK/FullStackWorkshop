package in.sp.model;

public class User {

}
