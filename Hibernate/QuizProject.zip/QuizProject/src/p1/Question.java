package p1;
import java.util.*;

public class Question {
	int id;
	String Question;
	List<String> answer;
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public String getQuestion() {
		return Question;
	}
	
	public void setQuestion(String question) {
		Question = question;
	}
	
	public List<String> getAnswer() {
		return answer;
	}
	
	public void setAnswer(List<String> answer) {
		this.answer = answer;
	}
}
