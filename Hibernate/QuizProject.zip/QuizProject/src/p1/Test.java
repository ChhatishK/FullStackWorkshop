package p1;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.*;
public class Test {

	public static void main(String[] args) {
		
		Session s=SessionUtility.getSession();
		Transaction tx=s.beginTransaction();
		Question q=new Question();
		q.setQuestion("What is Java?");
		ArrayList<String> l1=new ArrayList<String>();
		l1.add("Java is Programming Lang.");
		l1.add("Java is OOPS based and Open Source");
		q.setAnswer(l1);
		s.save(q);
		//*************
		Question q1=new Question();
		q1.setQuestion("What is Placement");
		ArrayList<String> l2=new ArrayList<String>();
		l2.add("To get Places in a company");
		l2.add("It is a struggle");
		q1.setAnswer(l2);
		s.save(q1);
		tx.commit();
		SessionUtility.closeSession();
	}

}
