package p1;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class SessionUtility {
	private static ThreadLocal<Session> ss=new ThreadLocal<Session>();
	private static  SessionFactory sf;
	private SessionUtility(){}
	static {
		
		Configuration c=new Configuration();
		c.configure("hibernate.cfg.xml");
		 sf=c.buildSessionFactory();
		
	}
	static Session getSession()
	{  
		Session s=ss.get();
		if(s==null)
		 s=	sf.openSession();
		
		return s;
	}
	static void closeSession()
	{
		Session s=ss.get();
		if(s!=null)
			s=null;
	}

}
