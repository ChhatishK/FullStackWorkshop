package p1;

import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class Test {
	public static void main(String args[]) {
		Configuration c = new Configuration();
		c.configure("hibernate.cfg.xml");
		SessionFactory sf = c.buildSessionFactory();
		Session s2 = sf.openSession();
		Transaction tx = s2.beginTransaction();
		
		Student s = new Student();
		s.setRollno(5);
		s.setName("Ramu");
		s.setCourse("B Tech");
		s2.save(s);
		
		tx.commit();
	}
}
