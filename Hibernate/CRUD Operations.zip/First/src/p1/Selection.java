package p1;

import org.hibernate.query.Query;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Selection {

	public static void main(String[] args) {
		Configuration c = new Configuration();
		c.configure("hibernate.cfg.xml");
		SessionFactory sf = c.buildSessionFactory();
		Session s = sf.openSession();
		Transaction tx = s.beginTransaction();
		Student std = s.load(Student.class, 5);
		
		Query<Student> q = s.createQuery("from Student where name=:naam");
		q.setParameter("naam", "Radhe");
		
		List<Student> lst = q.list();
		tx.commit();
		
		Iterator<Student> it = lst.iterator();
		
		while (it.hasNext()) {
			Student st = it.next();
			System.out.println("Rollno : "+st.getRollno()+", " +"Name : " + st.getName()+", "+"Course : "+ st.getCourse());
			
		}
	}

}
